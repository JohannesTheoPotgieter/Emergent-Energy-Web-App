*Previous Step*
[[Project Initiation Setup (PDPM1)]]

*Next Step*
[[Planning (PM1)]]

*People*
[[Project Developer]]
[[Project Manager]]
[[Head of Engineering]]
[[Program Manager]]
[[Procurement Manager]]

*Optional*
[[Construction Manager]]
[[HSE Officer]]
[[Compliance Officer]]
[[Head of Finance]]

*Process*
1. It is custom that the [[Hand over charter]] and [[Site visit report]] is taken as read before the meeting.
2. Everybody in the room has a chance to ask or raise questions about
	1. Scope
	2. Quality 
	3. Cost
	4. Time
3. In this meeting the [[Project Developer]] gives the [[Project Manager]] all the soft insights on how to handle the client and what type of client this is.
4. Estimated timelines and nuisances are discussed.
5. Project Scope should be very clear through the [[Hand over charter]]
6. Meeting should include Site visit report discussion.
	1. Reticulation of current site to be included. (If not PM needs to get this understood)
7. [[Project Manager]] to drive and own project from here on.

*Tool*
[[Hand over charter]]
[[Site visit report]]
[[MS Outlook]]
[[MS Teams]]

