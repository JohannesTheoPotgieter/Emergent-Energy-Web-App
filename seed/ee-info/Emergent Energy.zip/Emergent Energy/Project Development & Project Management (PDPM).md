
*People*
[[Head of Project Development]]
[[Chief Operations Officer]]
[[Head of Engineering]]
[[Program Manager]]
[[Procurement Manager]]
[[Compliance Officer]]
[[Project Developer]]
[[Project Manager]]

*Process*

1. [[Project Initiation Setup (PDPM1)]]
2. [[Client Hand Over (PDPM2)]]
3. [[SSEG Application Process (PDPM3)]]

*Tool*
[[MS Outlook]]
[[MS Teams]]
[[Hand over charter]]
[[Site visit report]]


