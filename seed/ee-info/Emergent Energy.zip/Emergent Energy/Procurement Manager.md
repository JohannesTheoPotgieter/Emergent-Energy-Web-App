*Role*
Procuring everything
assist with any procurement, purchase orders and lead times for delivery, payments to supplier and subcontractors

*Responsibility*
Fighting over money

*Assigned*
Mizelda Isaacs