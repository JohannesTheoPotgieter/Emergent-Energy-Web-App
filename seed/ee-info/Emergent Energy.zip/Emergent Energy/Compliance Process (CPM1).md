*People*
[[Compliance Officer]]
[[Project Developer]]
[[Program Manager]]
[[Project Manager]]

*Process*
**Compliance Management – Log all tickets on MS TEAMS Program management tasks**

- **Red Team** 
    - [[Project Manager]] to assign RED Team [[Click Up]] task to [[Compliance Officer]] and updates start date.
    - [[Compliance Officer]] schedules RED team on MS Teams Engineering support board or the Matriarch Support board.
	    - Internal [[Compliance Officer]] to schedule with [[Engineer]] and continue with next steps
	    - External [[Compliance Process (CPM1)]] to log ticket with external provider await confirmation.
    - [[Compliance Officer]] updates Due date for scheduled Red Team inspection date, assigns the [[Click Up]] task back to [[Project Manager]]
    - [[Compliance Officer]] updates Excel program tracker.
- **PrEng Sign - off****
    - **[[Project Manager]] to assign PrEng Sign - off [[Click Up]] task to [[Compliance Officer]] and updates start date.
    - [[Compliance Officer]] schedules PrEng Sign - off.
    - [[Compliance Officer]] updates Due date for scheduled PrEng Sign - off inspection date, assigns the [[Click Up]] task back to [[Project Manager]]
    - [[Compliance Officer]] updates Excel program tracker.
- **PTI Issued**
	- [[Project Manager]] to assign PTI [[Click Up]] task to [[Compliance Officer]] and updates start date.
    - [[Compliance Officer]] schedules PTI
    - [[Compliance Officer]] updates Due date for scheduled PTI due date, assigns the [[Click Up]] task back to [[Project Manager]]
    - [[Compliance Officer]] updates Excel program tracker.
- **Grid Approval**
	- [[Project Manager]] to assign Grid Approval [[Click Up]] task to [[Compliance Officer]] and updates start date.
    - [[Compliance Officer]] schedules Grid Approval
    - [[Compliance Officer]] updates Due date for scheduled Grid Approval due date, assigns the [[Click Up]] task back to [[Project Manager]]
    - [[Compliance Officer]] updates Excel program tracker.
- **NERSA application**
	- [[Project Manager]] to assign NERSA [[Click Up]] task to [[Compliance Officer]] and updates start date.
    - [[Compliance Officer]] schedules NERSA
    - [[Compliance Officer]] updates Due date for scheduled NERSA due date, assigns the [[Click Up]] task back to [[Project Manager]]
    - [[Compliance Officer]] updates Excel program tracker.
- **Scada Testing** 
	- [[Project Manager]] to assign SCADA Team [[Click Up]] task to [[Compliance Officer]] and updates start date.
    - [[Compliance Officer]] schedules SCADA Team on MS Teams Engineering support board or the Matriarch Support board.
    - [[Compliance Officer]] updates Due date for scheduled SCADA Team inspection date, assigns the [[Click Up]] task back to [[Project Manager]]
    - [[Compliance Officer]] updates Excel program tracker.
- **Powerplant commissioning**
	- [[Project Manager]] to assign Powerplant commissioning Team [[Click Up]] task to [[Compliance Officer]] and updates start date.
    - [[Compliance Officer]] schedules Powerplant commissioning Team 
	    - Internal [[Compliance Officer]] to schedule with [[Engineer]] and continue with next steps
	    - External [[Compliance Officer]] to log ticket with external provider await confirmation.
    - [[Compliance Officer]] updates Due date for scheduled Powerplant commissioning Team inspection date, assigns the [[Click Up]] task back to [[Project Manager]]
    - [[Compliance Officer]] updates Excel program tracker.

*Tools*
[[MS Teams]]
[[MS Outlook]]
[[Click Up]]
[[Dropbox]]