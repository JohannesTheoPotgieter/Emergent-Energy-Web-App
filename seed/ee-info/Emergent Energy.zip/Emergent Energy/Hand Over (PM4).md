*Previous Step*
[[Construction (PM3)]]
*Next Step*
[[Compliance Handover PM(5)]]
*People*
[[Construction Manager]]
[[Project Manager]]
[[Compliance Officer]]
[[Project Developer]]

*Process*
	1.Hand over documentation to be setup by [[Project Manager]] using the hand over templates.
	2. O&M handover to be setup with [[Compliance Officer]] a minimum of 3 days before the meeting files of the hand over should be shared so the O&M team can go through and prepare questions.
	3. Client hand over meeting, with [[Project Developer]], [[Project Manager]], and hand over presentation template as well as a framed picture
	4. All compliance needs to be closed out in this phase as well.
		1. PTI issued
		2. SSEG 
		3. Grid approval
		4. NERSA
		5. SCADA testing
*Tool*
[[MS Outlook]]
[[MS Teams]]
[[Click Up]]
[[Excel project tracker]]