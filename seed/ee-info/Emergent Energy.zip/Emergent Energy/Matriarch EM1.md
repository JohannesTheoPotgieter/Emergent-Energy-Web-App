*People*
[[Compliance Officer]]
[[Project Manager]]
[[Engineer]]
*Process*

1. Matriarch Hand over process
	1. [[Project Manager]] to assign [[Click Up]] ticket to [[Compliance Officer]], and update the start date to today
	2. [[Compliance Officer]] to send invite to [[Matriarch]] with hand over documents attached to the mail 5 days in advance.
	3. [[Project Manager]] to compile a list of all know open tasks in our world to take to the meeting.
2. Installer Fault Notification
	1. [[Matriarch]] to mail installer of site directly and cc in [[Compliance Officer]]. 
		1. This mails must include evidence of why its installer fault.
	2. [[Compliance Officer]] to log ticket on [[Emergent Energy]]  [[MS Teams]] Matriarch support board.
	3. Assigns ticket to himself and then if Matriarch needs support he can assign it to an [[Engineer]] or [[Project Manager]].
	4. [[Compliance Officer]] follows up with Matriarch weekly on ticket and if he can close on his side
3. Design Fault Notification
	1. [[Matriarch]] mails [[Compliance Officer]].
		1. This mail must include evidence on why its a design fault.
	2. [[Compliance Officer]] to log ticket on [[Emergent Energy]] [[MS Teams]] Matriarch support board
		1. Attach all evidence on ticket
		2. If he cannot solve the ticket assign to relevant [[Project Manager]] or [[Engineer]]
		3. [[MS Outlook]] or [[MS Teams]] to give the person context and a screenshot of the ticket
	3. [[Compliance Officer]] gives weekly feedback to [[Matriarch]] on the ticket
4. Red Team scheduling
	1. [[Compliance Officer]] mails Matriarch requesting Red Team to be on site.
	2. [[Matriarch]] response with scheduled time, [[Compliance Officer]] updates [[Click Up]] task with scheduled date and assigns back to [[Project Manager]]
5. Technician call out
	1. [[Project Manager]] mails [[Compliance Officer]] with request, and creates ticket on Matriarch support board. Attach screen shot of ticket in mail.
	2. [[Compliance Officer]] mails [[Matriarch]] to schedule the technician.
	3. Progress to be tracked on the ticket and updates be made on there by [[Compliance Officer]], while informing the [[Project Manager]] on [[MS Teams]].
6. Commissioning 
	1. [[Compliance Officer]] mails Matriarch requesting Commissioning  to be on site.
	2. [[Matriarch]] response with scheduled time, [[Compliance Officer]] updates [[Click Up]] task with scheduled date and assigns back to [[Project Manager]]
*Tools*
[[MS Teams]]
[[MS Outlook]]
[[Click Up]]
[[Program Summary Excel]]