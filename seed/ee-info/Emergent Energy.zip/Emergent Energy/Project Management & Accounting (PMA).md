*People*
[[Head of Finance]]
[[Chief Operations Officer]]
[[Procurement Manager]]
[[Program Manager]]
[[Construction Manager]]
[[Project Manager]]

*Process*
1. [[Procurement Process (PMA1)]]
2. [[Payment Requests (PMA2)]]
3. [[Client Invoicing Requests (PMA3)]]
4. [[Project Expense Claims (PMA4)]]
5. [[Inventory Management (PMA5) ]]

*Tools*
[[QuickBooks]]
[[MS Teams]]
[[Excel project tracker]]
[[Excel Purchase Order Template]]
