*People*
[[Project Developer]]

*Process*


*Tool*
SOLAR PHOTOVOLTAIC SITE INSPECTION FORM

|   |   |
|---|---|
|**Customer Details**|   |
|**Name:**||
|**Address:**||
|**Postal Code:**||
|**Telephone:**||
|**Email Address:**||

|   |   |   |
|---|---|---|
|**1.**|**Project Details**|   |
|**1.1**|**Site Usage:**<br><br>(e.g. School, Residential, Industrial, Commercial etc)||
|**1.2**|**GPS Coordinates:**||
|**1.3**|**Electricity Bill (6 – 12 months):**||
|**1.4**|**System Size Required:**||

|   |   |   |
|---|---|---|
|**2.**|**Roof Details**|   |
|**2.1**|**Existing roof suitable for Installation?**||
|**2.2**|**Roof Pitch:**||
|**2.3**|**Roof Type:**<br><br>(IBR, Kliplock, Corrugated, tile, slate, flat, concrete, gravel)||
|**2.4**|**Roof Access Points:**||

|   |   |   |
|---|---|---|
|**3.**|**Electrical Assessment**|   |
|**3.1**|**Electricity Provider:**||
|**3.2**|**Meter Type:**||
|**3.3**|**Current Billed Tariff:**||
|**3.4**|**Main DB Location:**||
|**3.5**|**Estimated length of cable from roof to proposed inverter location:**||
|**3.6**|**GSM/Wi-Fi/Ethernet:**||
|**3.7**|**Inverter Location:**||
|**3.8**|**Space for Additional DB near main DB:**||
|**3.9**|**Main Breaker Amperage Size:**||
|**3.10**|**Location of Existing sub-DB's:**||
|**3.11**|**Cable length from proposed inverter location to tie-in point:**||
|**3.12**|**Shared or Dedicated Transformer:**||
|**3.13**|**Transformer Breaker Size:**||

|   |   |   |
|---|---|---|
|**4.**|**Onsite Generator**|   |
|**4.1**|**Auto/ Manual Start Generator:**||
|**4.2**|**Other Relevant Generator Information:**||

|   |   |   |
|---|---|---|
|**5.**|**Photographs:**|   |
|**5.1**|**Roof from Inside:**||
|**5.2**|**Close-up of Roof Type:**||
|**5.3**|**Roof Access Points for Installation:**||
|**5.4**|**Available Schematics/CAD Drawings:**||
|**5.5**|**Potential Inverter Locations:**<br><br>(See Guidelines)||

|   |   |   |
|---|---|---|
|**6.**|**Sketch Plan**|   |
|**6.1**|**Details:**<br><br>(DB Location, proposed roof access etc)||
|**6.2**|**Measurements:**||
|**6.3**|**2D Vertical Sketch:**||
|**6.4**|**Available Roof Area:**<br><br>(Length x depth)||
|**6.5**|**Orientation/Azimuth:**||

|   |   |
|---|---|
|**Questions from site**|   |
|**Working hours**||
|**Noise restrictions during working hours?**||
|**Any reported roof leaks?**||
|**Module lay down area**||
|**Delivery truck limitations**||
|**If applicable, container lay down area**||
|**If applicable, scaffolding placement**||
|**Generators onsite**||
|**Shutdown limitations**||
|**Metering**||

|   |   |
|---|---|
|**Site Inspection Sign-off**|   |
|**Surveyor Name:**||
|**Surveyor Signature:**||
|**Quotation Possible:**||
|**Survey Information Accepted for Proposal:**||