*People*
[[Chief Operations Officer]]
[[Head of Engineering]]
[[Program Manager]]
[[Project Manager]]
[[Project Engineer]]


*Process*
1. [[Engineering Pack (EPM1)]]
2. [[Engineering Pack Update (EPM2)]]
3. [[Engineering Adhoc Request (EPM3)]]
4. [[Engineering Site Visit (EPM4)]]

*Tool*
[[MS Teams]]
[[MS Outlook]]
[[SharePoint]]
[[Click Up]]