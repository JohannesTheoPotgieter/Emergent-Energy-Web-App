*Previous Step*
[[Planning (PM1)]]

*Next Step*
[[Construction (PM3)]]

*People*
[[Project Manager]]
[[Program Manager]]
[[Procurement Manager]]
[[Construction Manager]]
[[Compliance Officer]]

*Process*
1. [[Project Manager]] initiates [[Procurement Process (PMA1)]]
2. [[Project Manager]] has in person kick - off meeting with client and shares, project brief and project kick off meeting presentation with them.
	1. Uploads project kick off presentation and project brief to [[SharePoint]]. [[Program Manager]] and [[Construction Manager]] to use this
3. [[Project Manager]] captures invoice for client deposit on [[MS Teams]].
4. [[Project Manager]] captures Planned Revenue, Planned Expense and track the actual expenses and revenue thought the applicable fields in [[Click Up]]
5. [[Project Manager]] captures running actual expense and revenue in [[Click Up]] through out the project.
6. [[Procurement Manager]] issues purchase orders and in charge of inventory logistics.
7. [[Project Manager]] to drive [[HSE Process]] with [[HSE Officer]] from [[Planning (PM1)]] in parallel.
	1. Safety file should be signed and loaded to [[Click Up]] task to be saved by [[HSE Officer]] in [[SharePoint]].
8. Notification of Construction works needs to be issued a minimum of 7 days before Site establishment.
9. [[Project Manager]] to drive [[Compliance Process (CPM1)]] with [[Compliance Officer]] in from [[Planning (PM1)]] in parallel
	1. All files and forms to be loaded to applicable [[Click Up]] task to be saved by [[Compliance Officer]] in [[Dropbox]]

*Tool*
1. [[Purchase Order generation template]]
2. [[MS Outlook]]
3. [[MS Teams]]
4. [[Click Up]]
5. [[Sub Contractor Agreement]]
7. [[QuickBooks]]
8. [[SharePoint]]
