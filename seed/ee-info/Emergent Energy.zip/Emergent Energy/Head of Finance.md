*Role*
Kaks everyone out

*Responsibility*
Money

*Assigned*
Tasneema Van Harte