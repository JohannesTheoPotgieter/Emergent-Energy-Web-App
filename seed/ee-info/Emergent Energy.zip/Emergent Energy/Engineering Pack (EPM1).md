
*People*
[[Quality Manager]]
[[Chief Operations Officer]]
[[Program Manager]]
[[Project Engineer]]
[[Design Engineer]]
[[Project Manager]]
[[Compliance Officer]]

*Process*
1.  At the [[Client Hand Over (PDPM2)]] meeting it is agreed upon what Engineering pack triage this project will be at:
		1. Are there client requirement outside of our regular process
		2. What is complex about it?
		3. Who is asking for the triage?
2. Team then decides which Project engineer will take ownership with the Project Manager on this project. 
3. If Green triage the Engineering pack request will be initiated by the creation of the project template on [[Click Up]]. 
	1. [[Project Engineer]] will then load the Green Triage engineering pack request on the Engineering board in [[Click Up]] and assign to an open [[Project Engineer]]
	2. Green Triage will consist of the following sections
		1. Site Development plan
		2. PVSOL - Module Layout
		3. String Layout
		4. SLD
	3. Once this is done it will be sent to Tanaka for review, and if needed [[Quality Manager]] will do another review. [[Project Engineer]] will then load the engineering pack under the applicable [[SharePoint]] folder.
	4. After this [[Chief Operations Officer]] will move the ticket to complete and close the Project side ticket with a comment the the engineering pack has been uploaded
4. If Red triage the Engineering pack request will be initiated by the creation of the project template on [[Click Up]]. 
	1. First step is for a [[Project Engineer]] to do a in depth site visit where the [[Project Engineer]] identify and compiles the needed section form the following suggestion list:
		1. Why is this a red site and address them
	2. After this [[Project Engineer]] will build this EP template on engineering board and assign to [[Project Engineer]] for compile
	3. . Once this is done it will be sent to Tanaka for review, and if needed [[Quality Manager]] will do another review. [[Project Engineer]] will then load the engineering pack under the applicable [[SharePoint]] folder.
	4. After this [[Project Engineer]]will move the ticket to complete and close the Project side ticket with a comment the the engineering pack has been uploaded
*Tool*
[[Click Up]]
[[MS Outlook]]
[[MS Teams]]
[[PVSOL]]
[[Autocad]]
[[Revert]]

