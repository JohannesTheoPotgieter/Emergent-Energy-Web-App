*Previous Step*
NA
*Next Step*
[[Payment Requests (PMA2)]]
*People*
[[Project Manager]]
[[Procurement Manager]]
[[Program Manager]]
[[Construction Manager]]

*Process*

1. [[Project Manager]] generates purchase order for approval using the excel template.
2. [[Project Manager]] sends purchase order for approval to [[Program Manager]],[[Construction Manager]].
3. [[Program Manager]],[[Construction Manager]] approves the purchase order and loads approval on [[MS Teams]] documents.
4. Once approved [[Project Manager]] sends Purchase order to supplier and requests invoice.

*Tool*
[[MS Teams]]
[[Purchase Order generation template]]