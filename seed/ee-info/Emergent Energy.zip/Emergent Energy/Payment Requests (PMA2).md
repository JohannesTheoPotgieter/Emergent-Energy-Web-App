*Previous Step*
[[Planning Execution (PM2)]]
*Next Step*
NA

*People*
[[Procurement Manager]]
[[Head of Finance]]
[[Chief Operations Officer]]
[[Project Manager]]

*Process*
	1. Payment runs are done every Thursday of the week, this is planned by the [[Procurement Manager]].
	2. Once a [[Procurement Process (PMA1)]] has been done that purchase order is sent to the vendor to receive a invoice.
	3. This invoice is then loaded on the MS TEAMS \ Accounts support team \ General \ Accounts Request.
	
*Tool*
[[MS Outlook]]
[[MS Teams]]
[[Click Up]]
[[Excel project tracker]]