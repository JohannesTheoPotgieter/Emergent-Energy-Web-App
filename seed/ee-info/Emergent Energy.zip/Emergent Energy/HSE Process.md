*People*
[[HSE Officer]]
[[Project Manager]]
[[Construction Manager]]

*Process*
1. [[Project Manager]] to fill out [[HSE Assessment template]] and upload onto [[Click Up]] task.
2. [[HSE Officer]] to review assessment.
	1. If nothing special he approves and uploads on the audit task as approved.
	2. If something special is needed:
		1. [[HSE Officer]] to establish whether he needs to do a site visit
			1. If not needed [[HSE Officer]] drives requirements through [[Project Manager]]
			2. If needed [[HSE Officer]] to organise site visit to assess the situation
			3. Then [[HSE Officer]] drive changes through [[Project Manager]]
3. Task completed and track by [[Construction Manager]] via [[Click Up]]

![[Pasted image 20240411114524.png]]
![[Pasted image 20240411114837.png]]

*Tools*
[[MS Outlook]]
[[Click Up]]
[[Dropbox]]
[[HSE Assessment template]]