*People*
[[Head of Project Development]]
[[Head of Project Development]]
[[Project Developer]]
[[Project Engineer]]

*Process*
1.  [[Project Developer]] loads Meter installation request on the pre engineering board  - this board is located on [[MS Teams]] in the Engineering Support team under the Pre Engineering section. They assign this to [[Chief Operations Officer]] of will then assign it to a  [[Project Engineer]] \  or installer when ready to be worked on.
2. Priority is defined by a field on the board and the [[Head of Project Development]] gives final approval.
3. [[Chief Operations Officer]] will assign this in the daily stand up with the engineering team and post progress updates under the announcements section of the Engineering Support team on [[MS TEAMS]].
	1. If assigned to internal [[Project Engineer]] they will ensure and confirm that its installed and when retrieval will happen and analysis of the data.
	2. If assigned to the [[Program Manager]] an outside installer will be used and formal process will be followed:
		1. Invoice to install meter by installer to be raised for approval from relevant person to [[Head of Project Development]]
		2. This approval shared with [[Program Manager]]
		3. Program manager goes through the normal [[Payment Requests (PMA2)]] procedure to pay this installer.
4. Once completed the [[Program Manager]] / [[Project Engineer]] will ensure the [[Project Developer]] has the info needed completed and the ticket on the board is marked completed.

*Tool*
[[MS Teams]]
[[MS Outlook]]
[[Excel Templates]]
[[SharePoint]]