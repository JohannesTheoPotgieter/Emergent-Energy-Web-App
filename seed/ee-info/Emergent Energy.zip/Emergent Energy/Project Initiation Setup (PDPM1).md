*Previous Step*
[[Final Offer Submission (PD5)]]
*Next Step*
[[Client Hand Over (PDPM2)]]

*People*
[[Project Developer]]
[[Program Manager]]
[[Procurement Manager]]
[[Quality Manager]]
[[Head of Finance]]
[[Compliance Officer]]
[[HSE Officer]]

*Process*
1. [[Project Developer]] to send an [[Client Hand Over (PDPM2)]] meeting request to Project management management team. 
2. This meeting request should have a [[Hand over charter]] and [[Site visit report]] attached to it, and should be sent with a minimum lead time of 3 days.
3. This will allow the Project management management team to do some preliminary planning
4. [[Chief Operations Officer]],[[Program Manager]] and [[Construction Manager]] aligns on who the [[Project Manager]] assigned will be
5. Project Engineering classification to be done with [[Program Manager]],[[Head of Engineering]]
6. [[Program Manager]] will then forward the [[Client Hand Over (PDPM2)]] meeting request to the assigned [[Project Manager]]

*Tool*
[[MS Outlook]]
[[MS Teams]]
[[Hand over charter]]
[[Site visit report]]
