*People*
[[Project Developer]]
[[Program Manager]]
[[Construction Manager]]
*Process*

*Tool*
|   |   |   |   |   |   |   |
|---|---|---|---|---|---|---|
  
|PROJECT CHARTER|   |   |   |   |   |![](file:///C:/Users/johan/AppData/Local/Temp/msohtmlclip1/01/clip_image002.png)<br><br>\|   \|<br>\|---\|<br>\||
||
|1. OVERVIEW|   |   |   |   |   |Description|
|Project Name||   |   |   |   |What is the name of the project in the active projects folder?|
|Site Address||   |   |   |   |What is the address of the site?|
|Site Coordinates||   |   |   |   |What are the coordiantes of the site?|
|Facility Type||   |   |   |   |Give a description of the facility. (Industrial, Commercial, Agri, School, Multiple)|
|Utility Supplier||   |   |   |   |Who is the utility supplier?|
|Existing Electrical Infrastructure||   |   |   |   |What is the condition of the existing electrical infrastructure? Is it a complaint infrastructure, are there any upgrades that we are required to be aware of? Do we have a copy of the Existing COC/AC Reticulation Drawings?|
|Existing Solar System, Generator, Batteries Onsite (Y/N)||   |   |   |   |Are there any existing systems onsite.|
|Loads supplied by existing systems||   |   |   |   |Which loads are supplied by the existing systems? Special, Essential, or Complete Backup.|
|Structural Assessment Completed & Conclusion||   |   |   |   |Was a structural assessment completed before the Cost Proposal was signed? What was the outcome of the report? Insert Hyperlink to report.|
|Roof Remedial Work (If Applicable)||   |   |   |   |Who is responsible for the roof remedial work? What is the schedule of the remedial work? Really get into the specifics if this is required.|
|Roof Profile - Picture Required||   |   |   |   |What is the roof profile? A cross-sectional picture MUST be attached. It should be in the site inspection report|
|Roof Condition||   |   |   |   |Do we have drone footage of the roof? If not, then the PM can take footage when doing a walkthrough with the installer. Any major issues must be raised DURING the Project Introduction meeting with the client. Any obstructions that the designer should be aware of?|
|Roof Access||   |   |   |   |Description and picture of roof access.|
|Site Access||   |   |   |   |Is there a sign-in procedure? Attach a picture of the entrance.|
|Site Visit Form - Hyperlink||   |   |   |   |Is the site visit form saved in the correct folder? If no, insert arranged date,|
|Site Visit Completed By||   |   |   |   |Who completed the site visit and have they been included in the meeitng?|
|Specifics - What to look out for||   |   |   |   |Any additional risks/opportunities that you would like to make the team aware of?|
|2. STAKEHOLDERS|   |   |   |   |   ||
|External Stakeholders|   |   |   |   |   ||
|Client Company Name (Pty, Trust)||   |   |   |   |What is the name of the company that the Project has been signed with?|
|Client Contact Name||   |   |   |   |What is the name of the contact person?|
|Client Contact Details||   |   |   |   |What is the contact details of the contact person?|
|Client Relationship History||   |   |   |   |What is the history of the relationship with the client? What kind of personality does the contact person have?|
|Connection to Emergent Energy||   |   |   |   |What is the company's connection to Emergent Energy?|
|New or Returning||   |   |   |   |Is this a new or returning client?|
|Internal Stakeholders:|   |   |   |   |   ||
|Project Developer||   |   |   |   |Who is the Project Developer?|
|Programme Manager||   |   |   |   |Who is the Programme Manager for the project?|
|Procurement Manager||   |   |   |   |Who is the Procurement Manager for the project?|
|Construction Manager||   |   |   |   |Who is the Construction Manager for the project?|
|Project Manager||   |   |   |   |Who is the Project Manager?|
|O&M Manager||   |   |   |   |Who is the O&M Manager?|
|Asset Manager||   |   |   |   |Who is the Asset Manager?|
|Complaince Officer||   |   |   |   |Who will be taking lead on the SSEG?|
|Safety Officer||   |   |   |   |Who is the dedicated safety officer for the project?|
|Designer||   |   |   |   |Who was the designer of the Project?|
|Preferred Installer||   |   |   |   |Does the client have a preferred installer? Who do we prefer to execute the project?|
|Specifics - What to look out for||   |   |   |   |Any additional risks/opportunities that you would like to make the team aware of?|
|3. SCOPE|   |   |   |   |   ||
|System Type (Grid Tied, BESS, etc.)||   |   |   |   |What type of system is the project?|
|System Size||   |   |   |   |What is the size, in kW,kVA of the system?|
|Battery/Gen Spec (If Applicable)||   |   |   |   |Elaborate on the spec if it is included in the project.|
|Module Spec (Sold to client & Design)||   |   |   |   |Which modules are mentioned in the cost proposal and which modules were used in the design?|
|Inverter Spec||   |   |   |   |Which inverters were sold?|
|Mounting Structure Spec||   |   |   |   |Which mounting structure will be used, dependant on the roof profile. This will only be confirmed if we have a picture of the roof profile.|
|Monitoring Spec||   |   |   |   |Depending on the system type, which monitoring platform will be used to monitor the plant. Any special monitoring requested by the client (Vcom)|
|Techsitter Meters Required (Fedgroup?)||   |   |   |   |Which meter types will be installed? Solar Production, Consumption?|
|Diesel Gen Integration||   |   |   |   |Does the project require gen integration? Has the site visit been done to confirm?|
|Dedicated feeder||   |   |   |   |Does the site have a dedicated feeder?|
|Transformer Size||   |   |   |   |What is the size of the transformer onsite? Attach Picture, included in the site inspection report.|
|Provisional Tie-In Point||   |   |   |   |Attach picture, has engineering approved?|
|Main Breaker Size||   |   |   |   |Attach picture, has engineering approved?|
|Description of the Inverter/DB Room||   |   |   |   |Attach picture, has engineering approved? Is this on the site inspection report? Is it in the same room as the tie-in?|
|Internet Access Available||   |   |   |   |Will the client provide internet access? If we have to do our own router, what is the signal strength in the area?|
|Specifics - What to look out for||   |   |   |   |Any additional risks/opportunities that you would like to make the team aware of?|
|HSE|   |   |   |   |   ||
|Client HSE Requirements||   |   |   |   |Did the client raise any additional requirements during the signing of the project?|
|Lifelines Required||   |   |   |   |Are there lifelines required?|
|Additional Security Required||   |   |   |   |Did the client raise any additional requirements during the signing of the project?|
|SSEG|   |   |   |   |   ||
|SSEG Submitted (Y/N and date of submission)||   |   |   |   |Has the application been submitted, what is the date of the submission?|
|SSEG Notification Number||   |   |   |   |What is the notification number?|
|Municipal Contact Person||   |   |   |   |Who is the contact person at the municipality?|
|Grid Study Required||   |   |   |   |Is there a grid study required?|
|Documents Received - Hyperlink||   |   |   |   |Attach a link to all the SSEG documents|
|O&M|   |   |   |   |   ||
|Contract Type||   |   |   |   |Was an O&M agreement included in the Cost Proposal?|
|Specific contract obligations relating to maintenance plan||   |   |   |   |Any additional requirements raised?|
|O&M Requirements (Waterpoints, etc.)||   |   |   |   |Did the AM raise any additional requirements?|
|Metering & Billing||   |   |   |   |Metering or blilling required?|
|Specifics - What to look out for||   |   |   |   |Any additional risks/opportunities that you would like to make the team aware of?|
|4. SCHEDULE|   |   |   |   |   |Below dates to be discussed during the handover. Commit to a specific week to complete an activity, do not put specific dates down unless requested by the client.|
|Internal Project Alignment Meeting||   |   |   |   ||
|Installer Walkthrough||   |   |   |   ||
|External Project Introduction Meeting||   |   |   |   ||
|Internal Project Review||   |   |   |   ||
|Client Kick -Off (If Required)||   |   |   |   ||
|Site Establishment||   |   |   |   ||
|Client Expected Completion Date (If Applicable)||   |   |   |   ||
|Handover - Matriarch||   |   |   |   ||
|Handover - Client||   |   |   |   ||
|Specifics - What to look out for||   |   |   |   |Any additional risks that you would like to make the team aware of.|
|5. BUDGET|   |   |   |   |   ||
|Funding Model||   |   |   |   |Which funding model was used?|
|Payment Terms/Payment Milestones||   |   |   |   |What were the agreed payment terms/milestones? Go through each one and raise additional requirements.|
|Conditions for Invoice Submission||   |   |   |   |Did the client raise any additional requirements during the signing of the project?|
|Funding Partner||   |   |   |   |Raise, if applicable.|
|Deposit Paid||   |   |   |   |Finance Department will confirm if deposit has been paid.|
|Costing Sheet - Hyperlink||   |   |   |   |Go through the costing sheet to get an overview of the cost of the project. Highlight budget for any additional scope.|
|BDP Commission||   |   |   |   |Is there any BDP Commission for this project?|
|Specifics - What to look out for||   |   |   |   |Any additional risks/opportunities that you would like to make the team aware of?|
|6. RISKS/OPPORTUNITIES/TRIAGE|   |   |   |   |   |Summarise each element.|
|Overview Summary||   |   |   |   ||
|Stakeholder Summary||   |   |   |   ||
|Scope Summary||   |   |   |   ||
|Schedule Summary||   |   |   |   ||
|Budget Summary||   |   |   |   ||
|Triage (Green/Amber/Purple)||   |   |   |   |Collectively agree on a triage level. Green/Amber/Purple|