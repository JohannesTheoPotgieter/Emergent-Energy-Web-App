*Previous Step*
[[Construction (PM3)]]
*Next Step*
[[Construction (PM3)]]
*People*
[[Project Manager]]
[[Compliance Officer]]
*Process*
1. When [[Click Up]] is created an Commissioning ticket is created. This is originally assigned to the [[Project Manager]]. 
2. Once the Commissioning is ready to be scheduled, they assign that ticket to the [[Compliance Officer]]. The [[Project Manager]] captures this as the start date of that task.
4. He will get a mail notifying him that this needs to be actioned.
	1. [[Compliance Officer]] than schedules a in house Commissioning on [[MS Teams]] - Engineering Support and updates [[Click Up]] task with the scheduled date as the Due date.
	2. [[Compliance Officer]] fills out the MAM template mail and mails MAM to please schedule the Commissioning, once [[Compliance Officer]] received the date from MAM, [[Compliance Officer]] updates the Due date on [[Click Up]].
5. Once the Due date has been captured [[Compliance Officer]] assigns the [[Click Up]] task back to the [[Project Manager]] and they can drive the task to completion.
*Tool*
[[Click Up]]
[[MS Outlook]]
[[MS Teams]]
