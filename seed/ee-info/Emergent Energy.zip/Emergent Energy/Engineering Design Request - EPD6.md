*People*
[[Head of Project Development]]
[[Head of Project Development]]
[[Project Developer]]
[[Design Engineer]]

*Process*
1.  [[Project Developer]] loads Engineering Design Request on the pre engineering board  - this board is located on [[MS Teams]] in the Engineering Support team under the Pre Engineering section. They assign this to [[Chief Operations Officer]] of will then assign it to a  [[Design Engineer]]  when ready to be worked on.
	1. Engineering Design request currently have two options:
		1. Size rational 
		2. Data Analysis
2. Priority is defined by a field on the board and the [[Head of Project Development]] gives final approval.
3. [[Chief Operations Officer]] will assign this in the daily stand up with the engineering team and post progress updates under the announcements section of the Engineering Support team on [[MS TEAMS]].
4. Once completed the [[Design Engineer]] will ensure the [[Project Developer]] has the design request form completed and the ticket on the board is marked completed.

*Tool*
[[MS Teams]]
[[MS Outlook]]
[[Excel Templates]]
[[SharePoint]]