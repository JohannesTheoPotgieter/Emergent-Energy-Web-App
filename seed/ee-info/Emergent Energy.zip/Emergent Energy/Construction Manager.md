*Role*
Building sites with people while building people, ensuring revenue milestones are met and invoiced on time
Assist with any installer management, construction phase, Project Managers report into this person

*Responsibility*
Listening

*Assigned*
Luke H