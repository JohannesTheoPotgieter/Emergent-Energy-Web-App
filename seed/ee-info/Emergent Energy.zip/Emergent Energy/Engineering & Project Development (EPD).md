
*People*
[[Chief Operations Officer]]
[[Compliance Officer]]
[[Head of Project Development]]
[[Project Developer]]
[[Program Manager]]
[[Design Engineer]]
[[Project Engineer]]

*Process*
	1. [[First Assessment Request - EPD1]]
	2. [[Cost Proposal Request - EPD2]]
	3. [[Tender Request - EPD3]]
	4. [[Site Visit Request - EPD4]]
	5. [[Meter installation request - EPD5]]
	6. [[Engineering Design Request - EPD6]]
	7. [[Data Tool request - EPD7]]
*Tool*
[[MS Teams]]
[[MS Outlook]]
[[Excel Templates]]
[[SharePoint]]
[[PVSOL]]
[[AutoCad]]
