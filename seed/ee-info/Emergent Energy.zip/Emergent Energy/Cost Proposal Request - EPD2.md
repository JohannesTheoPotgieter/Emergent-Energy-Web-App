*People*
[[Head of Project Development]]
[[Quality Manager]]
[[Project Developer]]
[[Design Engineer]]

*Process*
1.  [[Project Developer]] loads Cost Proposal Request on the pre engineering board  - this board is located on [[MS Teams]] in the Engineering Support team under the Pre Engineering section. They assign this to [[Quality Manager]] of will then assign it to a [[Design Engineer]] when ready to be worked on.
2. Priority is defined by a field on the board and the [[Head of Project Development]] gives final approval.
3. [[Chief Operations Officer]] will assign this in the daily stand up with the engineering team and post progress updates under the announcements section of the Engineering Support team on [[MS TEAMS]].
4. Once completed the [[Quality Manager]] will ensure the [[Project Developer]] has the CP Template populated and the ticket on the board is marked completed.

*Tool*
[[MS Teams]]
[[MS Outlook]]
[[Excel Templates]]
[[SharePoint]]