*Previous Step*
[[Planning Execution (PM2)]]
*Next Step*
[[Hand Over (PM4)]]

*People*
[[Construction Manager]]
[[Project Manager]]
[[Compliance Officer]]
[[HSE Officer]]
[[Engineer]]

*Process*
	1. Site establishment with [HSE Officer] optional, installer project manager needs to be there, [[Project Manager]] needs to be there, [[Construction Manager]] optional.
		1. Introduction to client
		2. Induction on site
		3. Setup of lay down area ect.
	2.  Material Delivery to site, to be coordinated between [[Project Manager]] and [[Procurement Manager]]
	3. Daily updates from Project manager of Installer in the following template:
		1. Date:
		2. Arrival time:
		3. Departure time:
		4. Management on site:
		5. Team members on site:
		6. Activities completed:
		7. Activities upcoming:
		8. House keeping done:
		9. Delays:
		10. Practical completion date:
	4. Module Installation
	5. AC Installation
	6. DC Installation
	7. Commissioning 
		1. Practical completion
		2. System Energised
		3. O&M soft monitoring
		4. Red Team Inspection
		5. Snag Completion
		6. PrEng Sign-Off
	8. Site Demobilizing
		1. Equipment Recon
		2. Site clean up
*Tool*
[[MS Outlook]]
[[MS Teams]]
[[Click Up]]
[[WhatsApp]]
[[Excel project tracker]]
