*Previous Step*

*Next Step*

*People*
[[Head of Engineering]]
[[Head of Project Development]]
[[Project Developer]]
*Process*
1. Use the Engineering Support/Cost proposals Reviews Channels
*Tool*
[[MS Teams]]
[[Cost Proposal Template]]