*Previous Step*
[[Client Hand Over (PDPM2)]]

*Next Step*
[[Planning Execution (PM2)]]

*People*
[[Project Manager]]
[[Program Manager]]
[[Procurement Manager]]
[[Construction Manager]]
[[HSE Officer]]

*Process*
1. [[Program Manager]] to setup [[Excel project tracker]] with estimated dates and costs.
	1. Complete  [[Click Up]] task, and [[Excel project tracker]] to be saved by [[Program Manager]] in [[SharePoint]]
2. [[Program Manager]] to setup initial [[BOQ]] and submit to [[Project Manager]].
	1. Complete  [[Click Up]] task, and [[BOQ]] to be saved by [[Program Manager]] in [[SharePoint]]
3. [[Project Manager]] to build project plan on [[Click Up]] from provided excel template, to track milestone and project delivery. (Critical Path focus in detail)
4. [[Project Manager]] to setup installer site walkthrough with [[Construction Manager]].
5. [[Program Manager]],[[Construction Manager]] to drive and ensure initial SLD & Engineering pack to be submitted with due date to [[Project Manager]] on [[Click Up]]. To be saved by [[Program Manager]] in [[SharePoint]]
6. [[Project Manager]] to compile [[Project Brief]], and save in [[SharePoint]].
7. [[Project Manager]] submits refined [[BOQ]] to [[Head of Engineering]] for sign-off.
	1. Green triage project does not need full engineering pack sign-off.
8. [[Project Manager]] to have initial meeting with installer to agree on estimate project plan, ensure that installer has an signed agreement in place
	1. Upload signed brief to [[SharePoint]]. - [[Program Manager]],[[Construction Manager]] to ensure installer has signed agreement
9. [[Project Manager]] to have initial meeting with client on  [[Client introduction presentation]].
10. [[Project Manager]] to kick off HSE process with [[HSE Officer]].
11. [[Project Manager]] to do initial Risk Assessment of project in [[Click Up]].
12. [[Project Manager]] to drive financial review with [[Program Manager]],[[Construction Manager]],[[Procurement Manager]],[[Project Manager]],[[Head of Finance]],[[Chief Operations Officer]] - 
	1. Depending on complexity of project this review can be done via:
		1. High - Review meeting
		2. Low - [[MS Teams]] approval process
			1. Attached the screenshot of cost vs actual margin 
			2. Project duration - kw per week we have to install against
			3. Appointed installer
			4. High risk items

*Tool*
1. [[MS Teams]]
2. [[MS Outlook]]
3. [[Click Up]]
4. [[BOQ]]
5. [[Excel project tracker]]
6. [[Project Brief]]
7. [[Client introduction presentation]]
8. [[Dropbox]]
9. [[SharePoint]]

