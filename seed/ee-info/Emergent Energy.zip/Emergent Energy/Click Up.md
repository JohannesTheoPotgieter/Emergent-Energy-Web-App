*People*
[[Chief Operations Officer]]
[[Procurement Manager]]
[[Construction Manager]]
[[Program Manager]]
[[Project Manager]]

*How to*
Starting a new project:
1. Click the plus sign on next to the active projects folder:
![[Pasted image 20240402100052.png]]
2. Then click the form template option:
![[Pasted image 20240402100456.png]]
3. From here choose the Project Template List from the templates from your workspace section:
![[Pasted image 20240402100659.png]]
4. After clicking this, click the use template button, from here you can enter a relevant project name:
![[Pasted image 20240402100809.png]]5. After about 5mins this will create your new project with the correct name, form here you can then build out your planning phase, assign tasks appropriately, you can click on the tracking column to update whether a task is GREEN,AMBER or RED status, you can also update and plan your start and due dates and make comments on a task:
![[Pasted image 20240402105958.png]]
6. Building your project plan in Click - UP then gives you access to a lot of features from the get go like:
	1. Gantt Chart
	![[Pasted image 20240402110819.png]]
	2. Projects Dashboard Internal - this is full customisable:
	![[Pasted image 20240402113629.png]]
	3. Client side dashboard - This is a dashboard which you can share with the client that allows them to track real time progress and chat with you:
	![[Pasted image 20240402114029.png]]
	